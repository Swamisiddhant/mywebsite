function showmsg(){
  alert("Thank you! Main jaldi contact karunga");
}
function whatsapp(){
  window.open("https://wa.me/919881019150");
}